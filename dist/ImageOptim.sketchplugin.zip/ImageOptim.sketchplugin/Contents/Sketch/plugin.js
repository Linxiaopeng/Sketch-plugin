var __globals = this;
!(function e(t, r, o) {
  function n(a, p) {
    if (!r[a]) {
      if (!t[a]) {
        var s = "function" == typeof require && require;
        if (!p && s) return s(a, !0);
        if (i) return i(a, !0);
        var c = new Error("Cannot find module '" + a + "'");
        throw (c.code = "MODULE_NOT_FOUND"), c;
      }
      var u = (r[a] = { exports: {} });
      t[a][0].call(
        u.exports,
        function (e) {
          var r = t[a][1][e];
          return n(r ? r : e);
        },
        u,
        u.exports,
        e,
        t,
        r,
        o
      );
    }
    return r[a].exports;
  }
  for (
    var i = "function" == typeof require && require, a = 0;
    a < o.length;
    a++
  )
    n(o[a]);
  return n;
})(
  {
    1: [
      function (e, t, r) {
        "use strict";

        // 显示提示信息的辅助函数
        function o(e) {
          var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 5;
          NSApplication.sharedApplication()
            .orderedDocuments()
            .firstObject()
            .displayMessage_timeout(e, t);
        }

        // 核心压缩函数，通过 NSWorkspace 启动 ImageOptim.app 并传入文件路径进行压缩
        function n(e, t, r) {
          if (t.length) {
            var n = NSWorkspace.sharedWorkspace(),
              i = "net.pornel.ImageOptim",
              a = n.URLForApplicationWithBundleIdentifier(i);
            if (!a)
              return (
                o("ImageOptim not installed", 10),
                void n.openURL(
                  NSURL.URLWithString("https://imageoptim.com/mac?sketch")
                )
              );
            var p =
              NSWorkspaceLaunchWithoutAddingToRecents | NSWorkspaceLaunchAsync;
            r &&
              (p =
                p |
                NSWorkspaceLaunchWithoutActivation |
                NSWorkspaceLaunchAndHide),
              n.openURLs_withAppBundleIdentifier_options_additionalEventParamDescriptor_launchIdentifiers_(
                t,
                i,
                p,
                null,
                null
              );
          }
        }

        // 过滤并获取存在的文件的 URL 列表
        function i(e) {
          for (var t = [], r = 0; r < e.count(); r++) {
            var o = e.objectAtIndex(r);
            NSFileManager.defaultManager().fileExistsAtPath(o.path) &&
              t.push(NSURL.fileURLWithPath(o.path));
          }
          return t;
        }

        // 显示保存对话框
        function a(e) {
          var t = NSOpenPanel.openPanel();
          t.setTitle("Export & Optimize All Assets In…"),
            t.setCanChooseFiles(!1),
            t.setCanChooseDirectories(!0),
            t.allowsMultipleSelection = !1,
            t.setCanCreateDirectories(!0),
            t.setPrompt("Export"),
            e && t.setDirectoryURL(e);
          var r = t.runModal();
          return r == NSOKButton ? t.URLs().firstObject().path() : null;
        }

        // 手动运行“Export and Optimize All Assets…”时的处理逻辑
        function p(e) {
          var t = e.document.allExportableLayers();
          if (t.count() > 0) {
            o("Exporting assets to ImageOptim");
            var r = a();
            if (r) {
              for (
                var p = NSMutableArray.alloc().init(), s = 0;
                s < t.count();
                s++
              ) {
                var c = t.objectAtIndex(s),
                  u = MSExportRequest.exportRequestsFromExportableLayer(c);
                if (u.count() > 0)
                  for (var l = 0; l < u.count(); l++) {
                    var m = u.objectAtIndex(l),
                      d = NSString.pathWithComponents([
                        r,
                        m.name() + "." + m.format(),
                      ]);
                    p.addObject({ request: m, path: d });
                  }
              }
              for (var h = 0; h < p.count(); h++) {
                var f = p.objectAtIndex(h),
                  _ = void 0;
                (_ =
                  "svg" == f.request.format()
                    ? MSExportRendererWithSVGSupport.exporterForRequest_colorSpace(
                        f.request,
                        NSColorSpace.sRGBColorSpace()
                      )
                    : MSExporter.exporterForRequest_colorSpace(
                        f.request,
                        NSColorSpace.sRGBColorSpace()
                      )),
                  _.data().writeToFile_atomically(f.path, !0);
              }
              var S = i(p);
              S.length > 0 ? n(e, S, !1) : coscript.setShouldKeepAround(!1);
            }
          } else o("No exportable layers in the document");
        }

        // 自动监听到 Sketch 导出事件时的处理逻辑
        function s(e) {
          var t = i(e.actionContext.exports);
          if (t.length > 0) {
            // 弹出弹窗询问用户是否压缩
            var alert = NSAlert.alloc().init();
            alert.setMessageText("是否使用 ImageOptim 压缩导出的图片？");
            alert.setInformativeText("检测到您刚导出了 " + t.length + " 个图片资源。");
            alert.addButtonWithTitle("压缩");
            alert.addButtonWithTitle("取消");
            
            var response = alert.runModal();
            if (response == 1000) {
              n(e, t, !0);
            }
          }
        }

        Object.defineProperty(r, "__esModule", { value: !0 });
        var c = (r.SketchPlugin = {
          name: "ImageOptim",
          description: "Optimize exported images with ImageOptim",
          author: "Kornel Lesiński & Ale Muñoz",
          authorEmail: "kornel@imageoptim.com",
          version: "1.0.0",
          identifier: "com.imageoptim.sketch",
          homepage: "https://imageoptim.com",
          compatibleVersion: 3.8,
          commands: {
            imageOptim: {
              name: "Export and Optimize All Assets…",
              handlers: {
                run: "___imageOptim_run_handler_",
                actions: {
                  ExportSlices: "___imageOptim_run_handler_",
                  Export: "___imageOptim_run_handler_",
                },
              },
              run: function (e) {
                e.actionContext ? s(e) : p(e);
              },
            },
          },
        });
        __globals.___imageOptim_run_handler_ = function (e, t) {
          c.commands.imageOptim.run(e, t);
        };
      },
      {},
    ],
  },
  {},
  [1]
);